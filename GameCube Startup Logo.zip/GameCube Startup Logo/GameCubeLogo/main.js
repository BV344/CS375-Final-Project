import * as THREE from "three";

const scene = new THREE.Scene();

//Sizes
const sizes = {
  width: window.innerWidth,
  height: window.innerHeight,
}

//Light
const pointLight = new THREE.PointLight(0xffffff, 1, 100);
pointLight.position.set(0,0,10);
scene.add(pointLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
directionalLight.position.set(-10, 10, 10);
scene.add(directionalLight);

//Camera
const camera = new THREE.PerspectiveCamera(45, sizes.width/sizes.height, 0.1, 100);
camera.position.set(-25, 25, 25);
const targetPosition = new THREE.Vector3(0, 0, 0);
camera.lookAt(targetPosition);
scene.add(camera)

// Create an object loader
const loader = new THREE.ObjectLoader();

// Load the scene from the JSON file
loader.load(
  './scene.json',
  function (object) {
    // Add the loaded scene to our existing scene
    scene.add(object);
  }
);

//Render
const canvas = document.querySelector('.webgl');
const renderer = new THREE.WebGLRenderer({canvas});
renderer.setSize(sizes.width, sizes.height);

function render() {
  requestAnimationFrame(render);
  renderer.render(scene, camera);
}
render();

